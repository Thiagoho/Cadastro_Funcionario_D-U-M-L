package com.Cadastro.Aluno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastandoAlunoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastandoAlunoApplication.class, args);
	}

}
