package com.Cadastro.Aluno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastandoAlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
